
<?php
include '../config.php';
include '../functions.php';
checkLogin();
if (!isAdmin()) exit("無權限");

if (isset($_POST['title'])) {
    $title = $_POST['title'];
    $desc = $_POST['desc'];
    $reward = $_POST['reward'];
    $deadline = $_POST['deadline'];
    mysqli_query($conn, "INSERT INTO tasks (title, description, reward, deadline) VALUES ('$title','$desc','$reward','$deadline')");
    $task_id = mysqli_insert_id($conn);
    $exp = mysqli_real_escape_string($conn, $_POST['exp']);
    $coins = mysqli_real_escape_string($conn, $_POST['coins']);
    $item_name = mysqli_real_escape_string($conn, $_POST['item_name']);
    mysqli_query($conn, "INSERT INTO rewards (task_id, exp, coins, item_name) VALUES ($task_id, $exp, $coins, '$item_name')");

}
$result = mysqli_query($conn, "SELECT * FROM tasks");
?>

<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <title>遊戲任務系統</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background-color: #1a1a2e;
        color: #eaeaea;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .game-title {
        font-size: 32px;
        font-weight: bold;
        color: #00ffcc;
        margin-bottom: 20px;
        text-shadow: 2px 2px 4px #000;
    }
    .btn-game {
        background-color: #00ffcc;
        border: none;
        color: #1a1a2e;
    }
    .btn-game:hover {
        background-color: #00ccaa;
    }
    .card {
        background-color: #16213e;
        border: 1px solid #00ffcc;
    }
    a { color: #00ffcc; }
</style>

</head>
<body class="d-flex flex-column align-items-center">
<div class="container mt-4">
<div class="game-title text-center">🎮 遊戲任務系統</div>

<h2>任務管理</h2>
<form method="POST" class="p-4 card mb-4">
    <input name="title" class="form-control mb-2" placeholder="標題" required>
    <input name="desc" class="form-control mb-2" placeholder="描述" required>
    <input name="reward" class="form-control mb-2" placeholder="獎勵" required>
    <input name="exp" class="form-control mb-2" placeholder="經驗值" required>
    <input name="coins" class="form-control mb-2" placeholder="金幣數量" required>
    <input name="item_name" class="form-control mb-3" placeholder="道具名稱" required>
    <input type="date" name="deadline" class="form-control mb-3" required>

    <input type="submit" value="新增" class="btn btn-game w-100">
</form>
<ul class="list-group">
<?php while ($row = mysqli_fetch_assoc($result)): ?>
    <li class="list-group-item bg-dark text-light">📝 <?= $row['title'] ?> - 🎁 <?= $row['reward'] ?> - ⏰ <?= $row['deadline'] ?></li>
<?php endwhile; ?>
</ul>
<a href="../logout.php" class="btn btn-link mt-4">登出</a>

</div></body></html>
