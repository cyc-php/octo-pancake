
<?php
$conn = mysqli_connect("localhost", "root", "", "game_task_platform");
if (!$conn) {
    die("資料庫連線失敗: " . mysqli_connect_error());
}
session_start();
?>
